# FPN ZoomMini — minimal 3-run ablation (RCLCOD commit b37a6b5)

## Install

From RCLCOD repository root, extract `fpn_zoom_min_release.zip` into the repository root,
keeping the `methods/` and `configs/curablation/` paths. Then run:

```bash
python apply_fpn_zoom_min.py
```

The installer registers `PvtV2B4_FPN_ZoomMini` and removes TWO redundant
`ops.resize(image, height=base_h, width=base_w)` lines from `basemain.py`,
one in `ImageTrainDataset` and one in `ImageTestDataset`. This makes
`image_m` and `image_l` independently sampled from the augmented original RGB.
It changes the preprocessing for all models, so re-run baseline A0/A1 AFTER
applying it; do not compare old A0 metrics to new A2 metrics.

## Exactly three comparisons

A0: single 384 FPN

```bash
python basemain_continuous.py --config configs/curablation/fpn_zoom_384.py --model-name PvtV2B4_FPN_NC_Curriculum
```

A1: single 576 FPN

```bash
python basemain_continuous.py --config configs/curablation/fpn_zoom_576.py --model-name PvtV2B4_FPN_NC_Curriculum
```

A2: dual 384+576 with gated residual lateral fusion at C2 and C3

```bash
python basemain_continuous.py --config configs/curablation/fpn_zoom_384.py --model-name PvtV2B4_FPN_ZoomMini
```

Optional A3: dual 384+576 with simple mean fusion, C2/C3

```bash
python basemain_continuous.py --config configs/curablation/fpn_zoom_384_mean.py --model-name PvtV2B4_FPN_ZoomMini
```

All three primary runs use the SAME clean/noisy lists, seed, loss, scheduler,
effective batch 8 (microbatch 4 x grad accumulation 2), epochs and evaluation.
Only resolution and fusion differ.

The original repository's `methods/fpn_baseline.py` stays unchanged. ZoomMini
inherits its `NoisyCODCurriculumLoss` and `forward()` exactly, replacing only
`body()`. Encoder weights and 1x1 lateral projections are shared between
input resolutions. C4/C5 stay on the medium path; only C2/C3 are fused.
The gate's residual projection starts at ZERO to reproduce FPN's medium
forward at initialization. Later it learns where to inject the large feature.

## Caveats

- A2 uses two full PVT encoder passes, so it is more expensive than A0/A1.
  Report total FLOPs and inference latency, not just accuracy.
- A2 *never* consumes box annotations. This deliberately isolates whether
  global multi-scale feature fusion works before testing box-guided ROI zoom.
- A2 improved > A1 and A0 on Fw/MAE, consistently across test sets/seeds:
  evidence that fusion helps rather than input resolution alone.
- If A2 > A0 but <= A1, the gain may just come from higher input resolution.
- If A2 is better than A1 but A3 is similar, the gated fusion mechanism itself
  may not be necessary; the extra branch may be sufficient.
- For stronger evidence, repeat promising runs with 3 seeds after a first pass.
- If out of memory at microbatch 4, reduce `__BATCHSIZE` to 2 and increase
  `grad_acc_step` to 4 for ALL configs, adjusting test.batch_size too.
